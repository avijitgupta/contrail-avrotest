gcc complementReverse.c combineReads.c utilities.c extend.c -o flash
